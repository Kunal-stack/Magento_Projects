/* app/code/KunalUpadhyay/SecondFooter/view/frontend/requirejs-config.js */
var config = {
    paths: {
        'guessingGame': 'KunalUpadhyay_SecondFooter/js/guessing-game'
    }
};
